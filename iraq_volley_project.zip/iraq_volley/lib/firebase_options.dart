// مُشتق من google-services.json (المشروع: volleyball-iraq).
// يغني عن تشغيل `flutterfire configure` للأندرويد.
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError('الويب غير مُسجَّل في Firebase بعد. سجّل تطبيق ويب ثم أضف خياراته هنا.');
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError('المنصة غير مدعومة: $defaultTargetPlatform');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyB6Qjn5UGJk3yRx-F3EPsVK_ZN3wH_ZKZ0',
    appId: '1:727712823053:android:fa3cb2be5ff2a45eb56244',
    messagingSenderId: '727712823053',
    projectId: 'volleyball-iraq',
    storageBucket: 'volleyball-iraq.firebasestorage.app',
  );
}
