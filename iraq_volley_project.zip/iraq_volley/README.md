# بطولة شهداء العراق للكرة الطائرة — Flutter + Firebase

مشروع Firebase: `volleyball-iraq` — حزمة الأندرويد: `com.iraq.volleyball`

## 1) إعداد Firebase (مرة واحدة، من لوحة التحكم)
- Authentication ← Sign-in method ← فعّل **Email/Password**.
- Firestore Database ← Create database.
- Storage ← Get started (لازم قبل نشر قواعد التخزين).
- ترقية المشروع إلى خطة **Blaze** (شرط Cloud Functions).

## 2) نشر الخادم
```bash
npm i -g firebase-tools && firebase login
cd functions && npm i && cd ..
firebase functions:secrets:set ADMIN_CODE     # الرمز السري الجديد (لا تستخدم 20072026 فهو ظاهر في ملفات الاختبار)
firebase functions:secrets:set PW_PEPPER      # نص عشوائي طويل
firebase deploy --only firestore:rules,storage,functions
```
- رفع الأسئلة: `node tools/seed.js questions` (يتطلب GOOGLE_APPLICATION_CREDENTIALS).
- أول مدير: `node tools/seed.js super <UID>` (اختياري؛ الكود الحالي يسمح أيضاً بالرمز السري لحساب سُجّل كـ"مدير المسؤولين").
- اختبار منطق الخادم: `node test/functions_test.js`

## 3) بناء APK
**GitHub Actions:** ارفع المجلد إلى مستودع GitHub (فرع main) ← تبويب Actions ← Build APK ← بعد النجاح نزّل `iraq-volley-apk` من Artifacts.
**Codemagic:** اربط المستودع؛ يقرأ `codemagic.yaml` تلقائياً.
**محلياً:** `bash tools/build_apk.sh` (يتطلب Flutter وJava 17 وPython 3) ← الناتج: `build/app/outputs/flutter-apk/app-release.apk`

السكربت يولّد مجلد android، ثم `tools/patch_android.py` يضبط applicationId وminSdk=23 والأذونات واسم التطبيق.
الـ APK موقَّع بمفتاح debug (يصلح للتثبيت المباشر)؛ للنشر على Google Play أنشئ keystore.

## ملاحظات
- الاتصال بـ Firebase عبر `lib/firebase_options.dart` (مأخوذ من google-services.json) — لا حاجة لـ flutterfire configure للأندرويد.
- Realtime Database غير مستخدمة في الكود (ولا يوجد `firebase_url` في google-services.json)؛ التطبيق يعتمد Firestore.
- `lib/home_tab.dart` الحالي **مؤقت**؛ استبدله بملفك الأصلي.
- فعّل App Check وقيّد مفتاح API من Google Cloud Console.
