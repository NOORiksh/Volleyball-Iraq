#!/usr/bin/env python3
"""يعدّل مشروع android المولَّد: applicationId، minSdk، الأذونات، اسم التطبيق. يدعم Groovy وKotlin DSL."""
import pathlib, re, shutil, sys

APP_ID = "com.iraq.volleyball"      # يطابق google-services.json
LABEL = "شهداء العراق"
app = pathlib.Path("android/app")
gradle = next((p for p in (app / "build.gradle.kts", app / "build.gradle") if p.exists()), None)
if gradle is None:
    sys.exit("لم يوجد android/app/build.gradle(.kts) — شغّل flutter create أولاً")

s = gradle.read_text(encoding="utf-8")
s, n1 = re.subn(r'(applicationId\s*=?\s*)"[^"]*"', r'\g<1>"%s"' % APP_ID, s)
s, n2 = re.subn(r'(minSdk(?:Version)?\s*=?\s*)flutter\.minSdkVersion', r'\g<1>23', s)
gradle.write_text(s, encoding="utf-8")
if n1 == 0:
    sys.exit("تعذر العثور على applicationId في " + str(gradle))
print(f"{gradle}: applicationId={n1} minSdk={n2}")

man = app / "src/main/AndroidManifest.xml"
m = man.read_text(encoding="utf-8")
perms = ""
for p in ("INTERNET", "POST_NOTIFICATIONS"):
    if f"android.permission.{p}" not in m:
        perms += f'    <uses-permission android:name="android.permission.{p}"/>\n'
if perms:
    m = m.replace("<application", perms + "    <application", 1)
if "<queries>" not in m:
    q = ('    <queries>\n      <intent><action android:name="android.intent.action.VIEW"/>'
         '<data android:scheme="https"/></intent>\n    </queries>\n')
    m = m.replace("<application", q + "    <application", 1)
m = re.sub(r'android:label="[^"]*"', f'android:label="{LABEL}"', m, count=1)
man.write_text(m, encoding="utf-8")

shutil.copy("config/google-services.json", app / "google-services.json")
print("AndroidManifest + google-services.json OK")
