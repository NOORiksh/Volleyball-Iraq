#!/usr/bin/env bash
# يبني APK قابل للتثبيت. يعمل من جذر المشروع: bash tools/build_apk.sh
set -euo pipefail
cd "$(dirname "$0")/.."

# flutter create لا يجب أن يمس lib/ و pubspec.yaml: نحفظهما ونعيدهما
rm -rf /tmp/_bak && mkdir -p /tmp/_bak
cp -r lib pubspec.yaml /tmp/_bak/
flutter create --platforms=android --org com.iraq --project-name iraq_volley .
rm -rf lib pubspec.yaml && cp -r /tmp/_bak/lib /tmp/_bak/pubspec.yaml .
rm -f test/widget_test.dart

python3 tools/patch_android.py
flutter pub get
flutter build apk --release
echo "✔ APK: build/app/outputs/flutter-apk/app-release.apk"
